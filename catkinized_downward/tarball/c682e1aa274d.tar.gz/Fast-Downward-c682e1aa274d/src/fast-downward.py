#! /usr/bin/env python
# -*- coding: utf-8 -*-

if __name__ == "__main__":
    from driver.main import main
    main()
